Users must have JAVA 8 installed and processing to
open the .pde files as well as execute them with Processing methods present.