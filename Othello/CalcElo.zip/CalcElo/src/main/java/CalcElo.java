
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;

class CalcElo {

    static HashMap<String, Float> playerRatings = new HashMap();

    // Function to calculate the Probability 
    static float calculateProbability(float rating1,
                             float rating2)
    {
        return 1.0f * 1.0f / (1 + 1.0f *
                (float)(Math.pow(10, 1.0f *
                        (rating1 - rating2) / 400)));
    }

    static void updateRatings(HashMap map, String player1, String player2, float winner){

        map = playerRatings;

        float[] rating = EloRating(playerRatings.get(player1), playerRatings.get(player2), 64, winner);
        playerRatings.put(player1, rating[0]);
        playerRatings.put(player2, rating[1]);


    }
 
    static float[] EloRating(float playerA, float playerB,
                          float K, float d)
    {

		//prob of B winning
        float probB = calculateProbability(playerA, playerB);

		//Prob of A winning
        float probA = calculateProbability(playerB, playerA);

        //Player 1 wins
        if (d == 1) {
            playerA = playerA + K * (1 - probA);
            playerB = playerB + K * (0 - probB);
            playerA = (float) (Math.round(playerA * 1000000.0) / 1000000.0);
            playerB = (float) (Math.round(playerB * 1000000.0) / 1000000.0);
            return new float [] {playerA, playerB};
        }

        //Player 2 wins
        else if (d == 0){
            playerA = playerA + K * (0 - probA);
            playerB = playerB + K * (1 - probB);
            playerA = (float) (Math.round(playerA * 1000000.0) / 1000000.0);
            playerB = (float) (Math.round(playerB * 1000000.0) / 1000000.0);
            return new float [] {playerA, playerB};
        }else{
            return null;
        }

    }

    public static void main (String[] args)
    {

        try {
            Reader reader = Files.newBufferedReader(Paths.get("matches.csv"));
            BufferedWriter writer = Files.newBufferedWriter(Paths.get("elo_ratings.csv"));
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);
            CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("Player Name", "Elo Rating"));
            playerRatings.put("Yoan", (float) 1500);
            playerRatings.put("Sid", (float) 1500);
            playerRatings.put("Nikolay", (float) 1500);
            playerRatings.put("Joe", (float) 1500);
            playerRatings.put("Antoine", (float) 1500);
            playerRatings.put("Hari", (float) 1500);
            playerRatings.put("Allen", (float) 1500);
            playerRatings.put("Spas", (float) 1500);
            playerRatings.put("Andrew", (float) 1500);
            playerRatings.put("Boyan", (float) 1500);
            playerRatings.put("Ahmad", (float) 1500);
            playerRatings.put("Chris", (float) 1500);
            for(CSVRecord record : csvParser){
                String player1 = record.get(0);
                String player2 = record.get(1);
                float winner = Float.valueOf(record.get(2));

                updateRatings(playerRatings, player1, player2, winner);
                for(int i = 0; i < 12; i++ ){
                    csvPrinter.printRecord(playerRatings.keySet().toArray()[i], playerRatings.get(playerRatings.keySet().toArray()[i]));
                    csvPrinter.printRecord("----------------");
                }
                csvPrinter.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(playerRatings);
    }
} 
  